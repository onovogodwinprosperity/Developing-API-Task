import express from 'express';
import Note from '../models/Note';
import { validateNote } from '../middleware/validateRequest';

const router = express.Router();

// GET /api/notes - List all notes
router.get('/', async (req, res) => {
  try {
    const notes = await Note.find();
    res.json(notes);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/notes/:id - Get a specific note
router.get('/categories/:categoryId', async (req, res) => {
    try {
      const notes = await Note.find({ category: req.params.categoryId }).populate('category');
      res.json(notes);
    } catch (err) {
      res.status(500).json({ message: 'Server error' });
    }
  });


  router.put('/:id', validateNote, async (req, res) => {
    try {
      const { title, content, category } = req.body;
      const note = await Note.findByIdAndUpdate(
        req.params.id,
        { title, content, category },
        { new: true }
      );
      if (!note) {
        return res.status(404).json({ message: 'Note not found' });
      }
      res.json(note);
    } catch (err) {
      res.status(500).json({ message: 'Server error' });
    }
  });




// POST /api/notes - Create a new note
router.post('/', validateNote, async (req, res) => {
    try {
      const { title, content, category } = req.body;
      const note = new Note({ title, content, category });
      await note.save();
      res.status(201).json(note);
    } catch (err) {
      res.status(500).json({ message: 'Server error' });
    }
  });


// DELETE /api/notes/:id - Delete a note
router.delete('/:id', async (req, res) => {
  try {
    const note = await Note.findByIdAndDelete(req.params.id);
    if (!note) {
      return res.status(404).json({ message: 'Note not found' });
    }
    res.json({ message: 'Note deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;