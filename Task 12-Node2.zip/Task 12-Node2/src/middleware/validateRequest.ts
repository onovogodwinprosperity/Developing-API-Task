import { Request, Response, NextFunction } from 'express';
import { NoteSchema, NoteInput } from '../validators/noteValidator';
import { HttpError } from '../errors/HttpError';

export const validateNote = (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = NoteSchema.safeParse(req.body);
    if (!result.success) {
      throw new HttpError(400, 'Invalid note data');
    }
    req.body = result.data;
    next();
  } catch (err) {
    next(err);
  }
};