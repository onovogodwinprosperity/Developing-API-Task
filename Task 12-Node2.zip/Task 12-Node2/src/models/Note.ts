import { Document, Schema, model, Types } from 'mongoose';
import ICategory from './Category';

export interface INote extends Document {
  title: string;
  content: string;
  category: Types.ObjectId | ICategory;
  createdAt: Date;
  updatedAt: Date;
}

const NoteSchema = new Schema<INote>(
  {
    title: { type: String, required: true },
    content: { type: String, required: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
  },
  { timestamps: true }
);

export default model<INote>('Note', NoteSchema);

import { Document, Schema, model, Types } from 'mongoose';
import ICategory from './Category';

export interface INote extends Document {
  title: string;
  content: string;
  category: Types.ObjectId | ICategory;
  createdAt: Date;
  updatedAt: Date;
}

const NoteSchema = new Schema<INote>(
  {
    title: { type: String, required: true },
    content: { type: String, required: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
  },
  { timestamps: true }
);

export default model<INote>('Note', NoteSchema);

router.post('/', async (req, res) => {
    try {
      const { title, content, category } = req.body;
      const note = new Note({ title, content, category });
      await note.save();
      res.status(201).json(note);
    } catch (err) {
      res.status(500).json({ message: 'Server error' });
    }
  });