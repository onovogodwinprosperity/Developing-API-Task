import { HttpError } from '../errors/HttpError';

export class HttpError extends Error {
    constructor(public statusCode: number, message: string) {
      super(message);
      this.name = 'HttpError';
    }
  }
// Example in GET /api/notes/:id
router.get('/:id', async (req, res, next) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) {
      throw new HttpError(404, 'Note not found');
    }
    res.json(note);
  } catch (err) {
    next(err);
  }
});

// Add error handling middleware in src/index.ts
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err instanceof HttpError) {
    res.status(err.statusCode).json({ message: err.message });
  } else {
    res.status(500).json({ message: 'Server error' });
  }
});